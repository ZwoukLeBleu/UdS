Pour compiler les fichiers de l'examen formatif:
    1 - Créér le fichier "formatif-fonctions.c", tel que demandé dans l'énoncé du formatif
    2 - Changer la commande "construire" de Geany pour:
            gcc -Wall -o formatif-main formatif-main.c formatif-fonctions.c
        L'exécutable se nomme alors "formatif-main.exe"
