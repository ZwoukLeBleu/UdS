Les détails à propos de l'autovalidation sont dans la documentation.

La commande avec Geany pour construire avec l'autovalidation est la suivante:

gcc -static gestion_images.c bibliotheque_images.c -L. -lAutoValidation -o gestion_images
