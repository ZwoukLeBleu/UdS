#include "Chien.h"

Chien::Chien(string n)
{ set_nom(n);}

void Chien:: parler()
{ cout << "Wouaf-Wouaf!" << endl; }
