#include "Poisson.h"

Poisson::Poisson(string n)
{ set_nom(n);}

void  Poisson:: parler()
{ cout << "blub blub!!" << endl; }
