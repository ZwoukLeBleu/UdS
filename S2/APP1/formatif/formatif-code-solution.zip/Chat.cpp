#include "Chat.h"

Chat::Chat(string n)
{ set_nom(n);}

void Chat::parler()
{ cout << "Miaou!" << endl; }
