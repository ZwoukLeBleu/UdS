#include "Mammifere.h"

Mammifere::Mammifere()
{ cout << "Voici un Mammifere " << get_nom() << endl; }

Mammifere::~Mammifere()
{ cout << "Adieu Mammifere " << get_nom() << endl; }

void Mammifere::parler();
{
	cout << "" << endl;
}
