#include "Oiseau.h"

Oiseau::Oiseau(string n)
{ set_nom(n);}

void  Oiseau:: parler()
{ cout << "Twit-Twit!" << endl; }
