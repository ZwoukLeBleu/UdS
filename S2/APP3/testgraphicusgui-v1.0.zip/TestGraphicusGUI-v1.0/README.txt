L'application TestGraphicusGUI affiche aléatoirement des formes chaque fois que la commande de réinitialisation du canevas est donnée. Toutes les autres méthodes virtuelles n'ont pas été redéfinies.

Pour la compilation de cet exemple: consultez l'annexe sur GraphicusGUI dans le guide étudiant.
