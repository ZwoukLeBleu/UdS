Installation:

Pour installer la librairie GraphicusGUI, il suffit d'en mettre une copie dans un endroit que votre compilateur peut trouver. Un endroit simple est dans le même répertoire que le code source de votre projet qui utilise cette librairie.